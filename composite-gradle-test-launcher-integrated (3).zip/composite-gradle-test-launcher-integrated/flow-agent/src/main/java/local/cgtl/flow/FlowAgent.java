package local.cgtl.flow;

import java.io.*;
import java.lang.instrument.Instrumentation;
import java.lang.reflect.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import net.bytebuddy.asm.Advice;
import net.bytebuddy.implementation.bytecode.assign.Assigner;

public final class FlowAgent {
  private static final ConcurrentHashMap<String, Long> transformStartedNanos = new ConcurrentHashMap<>();
  private static final AtomicLong transformMatchedCount = new AtomicLong();
  private static final AtomicLong transformCompletedCount = new AtomicLong();
  private static final AtomicLong transformTotalNanos = new AtomicLong();
  private static final AtomicLong transformMaxNanos = new AtomicLong();
  private static volatile String transformMaxType = "<none>";
  private static final long SLOW_TRANSFORM_NANOS = Long.getLong("cgtl.flow.perf.slowTransformMs", 5L) * 1_000_000L;

  public static void premain(String args, Instrumentation inst) {
    try {
      long phaseStarted = System.nanoTime();
      Recorder.initialize();
      System.err.println("[CGTL PERF METHOD] recorderInitialize=" + millisSince(phaseStarted));
      phaseStarted = System.nanoTime();
      ClassLoader loader = ClassLoader.getSystemClassLoader();
      Class<?> builderDefault = Class.forName("net.bytebuddy.agent.builder.AgentBuilder$Default", true, loader);
      Class<?> transformerType = Class.forName("net.bytebuddy.agent.builder.AgentBuilder$Transformer", true, loader);
      Class<?> matchers = Class.forName("net.bytebuddy.matcher.ElementMatchers", true, loader);
      Class<?> advice = Class.forName("net.bytebuddy.asm.Advice", true, loader);
      System.err.println("[CGTL PERF METHOD] byteBuddyClassLoad=" + millisSince(phaseStarted));
      phaseStarted = System.nanoTime();
      Object matcher = buildMatcher(matchers);
      System.err.println("[CGTL PERF METHOD] matcherBuild=" + millisSince(phaseStarted));
      phaseStarted = System.nanoTime();
      Object builder = builderDefault.getConstructor().newInstance();
      Class<?> listenerType = Class.forName("net.bytebuddy.agent.builder.AgentBuilder$Listener", true, loader);
      Object listener = Proxy.newProxyInstance(loader, new Class<?>[]{listenerType}, (proxy, method, values) -> {
        String callback = method.getName();
        String typeName = values != null && values.length > 0 ? String.valueOf(values[0]) : "<unknown>";
        if ("onTransformation".equals(callback)) {
          recordTransformComplete(typeName);
        } else if ("onError".equals(callback)) {
          discardTransform(typeName);
          Throwable error = values != null && values.length > 4 && values[4] instanceof Throwable ? (Throwable) values[4] : null;
          System.err.println("[CGTL FLOW] Skipping " + typeName + " after transformation error: " + error);
          if (error != null) error.printStackTrace(System.err);
        }
        if ("toString".equals(method.getName())) return "CGTL Snapshot Listener";
        if ("hashCode".equals(method.getName())) return System.identityHashCode(proxy);
        if ("equals".equals(method.getName())) return proxy == (values == null ? null : values[0]);
        return null;
      });
      builder = call(builder, "with", listener);
      builder = call(builder, "type", matcher);
      InvocationHandler handler = (proxy, method, values) -> {
        if ("transform".equals(method.getName())) {
          Object dynamicBuilder = values[0];
          String typeName = String.valueOf(values[1]);
          transformMatchedCount.incrementAndGet();
          transformStartedNanos.put(typeName, System.nanoTime());
          try {
            Object methodMatcher = staticCall(matchers, "isMethod");
            methodMatcher = call(methodMatcher, "and", staticCall(matchers, "not", staticCall(matchers, "isAbstract")));
            methodMatcher = call(methodMatcher, "and", staticCall(matchers, "not", staticCall(matchers, "isNative")));
            // javac emits lambda bodies as private synthetic lambda$... methods on the enclosing class.
            // Synthetic methods therefore must participate in Replay; bridge methods remain excluded.
            methodMatcher = call(methodMatcher, "and", staticCall(matchers, "not", staticCall(matchers, "isBridge")));
            Object visitor = staticCall(advice, "to", MethodAdvice.class);
            Object transformed = call(dynamicBuilder, "visit", call(visitor, "on", methodMatcher));
            System.err.println("[CGTL FLOW] Snapshot tracing " + typeName);
            return transformed;
          } catch (Throwable error) {
            discardTransform(typeName);
            System.err.println("[CGTL FLOW] Skipping " + typeName + " after transformer setup error: " + error);
            error.printStackTrace(System.err);
            return dynamicBuilder;
          }
        }
        if ("toString".equals(method.getName())) return "CGTL Snapshot Transformer";
        if ("hashCode".equals(method.getName())) return System.identityHashCode(proxy);
        if ("equals".equals(method.getName())) return proxy == (values == null ? null : values[0]);
        return null;
      };
      Object transformer = Proxy.newProxyInstance(loader, new Class<?>[]{transformerType}, handler);
      System.err.println("[CGTL PERF METHOD] builderSetup=" + millisSince(phaseStarted));
      phaseStarted = System.nanoTime();
      call(call(builder, "transform", transformer), "installOn", inst);
      System.err.println("[CGTL PERF METHOD] installOn=" + millisSince(phaseStarted));
      System.err.println("[CGTL FLOW] Snapshot agent installed for packages: " + System.getProperty("cgtl.flow.packages", "<all>"));
      System.err.println("[CGTL FLOW] Snapshot agent exclusions: " + System.getProperty("cgtl.flow.excludes", "<none>"));
      Runtime.getRuntime().addShutdownHook(new Thread(() -> {
        System.err.println("[CGTL PERF METHOD TRANSFORM] matched=" + transformMatchedCount.get()
            + " transformed=" + transformCompletedCount.get()
            + " total=" + nanosToMillis(transformTotalNanos.get())
            + " max=" + nanosToMillis(transformMaxNanos.get())
            + " maxType=" + transformMaxType);
      }, "cgtl-method-transform-perf"));
    } catch (Throwable t) {
      System.err.println("[CGTL FLOW] Agent disabled: " + t);
      t.printStackTrace();
    }
  }

  private static void recordTransformComplete(String typeName) {
    Long started = transformStartedNanos.remove(typeName);
    if (started == null) return;
    long elapsed = System.nanoTime() - started;
    transformCompletedCount.incrementAndGet();
    transformTotalNanos.addAndGet(elapsed);
    updateTransformMax(typeName, elapsed);
    if (elapsed >= SLOW_TRANSFORM_NANOS) {
      System.err.println("[CGTL PERF METHOD TRANSFORM CLASS] " + typeName + "=" + nanosToMillis(elapsed));
    }
  }

  private static void discardTransform(String typeName) {
    transformStartedNanos.remove(typeName);
  }

  private static void updateTransformMax(String typeName, long elapsed) {
    long current;
    do {
      current = transformMaxNanos.get();
      if (elapsed <= current) return;
    } while (!transformMaxNanos.compareAndSet(current, elapsed));
    transformMaxType = typeName;
  }

  private static String nanosToMillis(long nanos) {
    return String.format(java.util.Locale.ROOT, "%.3fms", nanos / 1_000_000.0);
  }

  private static String millisSince(long started) {
    return nanosToMillis(System.nanoTime() - started);
  }

  static Object buildMatcher(Class<?> matchers) throws Exception {
    String raw = System.getProperty("cgtl.flow.packages", "").trim();
    Object matcher = staticCall(matchers, "none");
    for (String token : raw.split(",")) {
      String pkg = token.trim();
      if (pkg.isEmpty()) continue;
      matcher = call(matcher, "or", staticCall(matchers, "nameStartsWith", pkg + "."));
      matcher = call(matcher, "or", staticCall(matchers, "named", pkg));
    }
    String excludes = System.getProperty("cgtl.flow.excludes", "").trim();
    Object excluded = staticCall(matchers, "none");
    for (String token : excludes.split(",")) {
      String rule = token.trim();
      if (rule.isEmpty()) continue;
      if (rule.startsWith("package:")) {
        String pkg = rule.substring("package:".length()).trim();
        if (!pkg.isEmpty()) {
          excluded = call(excluded, "or", staticCall(matchers, "nameStartsWith", pkg + "."));
          excluded = call(excluded, "or", staticCall(matchers, "named", pkg));
        }
      } else if (rule.startsWith("class:")) {
        String cls = rule.substring("class:".length()).trim();
        if (!cls.isEmpty()) {
          excluded = call(excluded, "or", staticCall(matchers, "named", cls));
          excluded = call(excluded, "or", staticCall(matchers, "nameStartsWith", cls + "$"));
        }
      }
    }
    String adapterClasses = System.getProperty("cgtl.flow.stateAdapters", "").trim();
    for (String token : adapterClasses.split(",")) {
      String adapterClass = token.trim();
      if (adapterClass.isEmpty()) continue;
      excluded = call(excluded, "or", staticCall(matchers, "named", adapterClass));
      excluded = call(excluded, "or", staticCall(matchers, "nameStartsWith", adapterClass + "$"));
    }
    matcher = call(matcher, "and", staticCall(matchers, "not", excluded));
    // Test classes within the selected package are intentionally included.
    // This lets ordered replay begin at the actual test line that initiates the call.
    matcher = call(matcher, "and", staticCall(matchers, "not", staticCall(matchers, "isInterface")));
    matcher = call(matcher, "and", staticCall(matchers, "not", staticCall(matchers, "isAnnotation")));
    matcher = call(matcher, "and", staticCall(matchers, "not", staticCall(matchers, "isEnum")));
    matcher = call(matcher, "and", staticCall(matchers, "not", staticCall(matchers, "isRecord")));
    matcher = call(matcher, "and", staticCall(matchers, "not", staticCall(matchers, "isSynthetic")));
    matcher = call(matcher, "and", staticCall(matchers, "not", staticCall(matchers, "isSubTypeOf", Throwable.class)));
    return matcher;
  }
  static Object staticCall(Class<?> type, String name, Object... args) throws Exception { return find(type.getMethods(), name, args).invoke(null, args); }
  static Object call(Object target, String name, Object... args) throws Exception { return find(target.getClass().getMethods(), name, args).invoke(target, args); }
  static Method find(Method[] methods, String name, Object[] args) throws NoSuchMethodException {
    outer: for (Method method : methods) {
      if (!method.getName().equals(name) || method.getParameterCount() != args.length) continue;
      Class<?>[] parameters = method.getParameterTypes();
      for (int i = 0; i < parameters.length; i++) if (args[i] != null && !box(parameters[i]).isAssignableFrom(args[i].getClass())) continue outer;
      return method;
    }
    throw new NoSuchMethodException(name);
  }
  static Class<?> box(Class<?> type) {
    if (!type.isPrimitive()) return type;
    if (type == int.class) return Integer.class; if (type == long.class) return Long.class; if (type == boolean.class) return Boolean.class;
    if (type == byte.class) return Byte.class; if (type == short.class) return Short.class; if (type == char.class) return Character.class;
    if (type == float.class) return Float.class; if (type == double.class) return Double.class; return type;
  }

  public static class MethodAdvice {
    @Advice.OnMethodEnter
    public static long enter(@Advice.Origin("#t") String className,
                             @Advice.Origin("#m") String methodName,
                             @Advice.Origin("#d") String descriptor,
                             @Advice.This(optional = true) Object receiver,
                             @Advice.AllArguments(typing = Assigner.Typing.DYNAMIC) Object[] arguments) {
      return Recorder.enter(className, methodName, descriptor, receiver, arguments);
    }

    @Advice.OnMethodExit(onThrowable = Throwable.class)
    public static void exit(@Advice.Enter long callId,
                            @Advice.This(optional = true) Object receiver,
                            @Advice.Return(typing = Assigner.Typing.DYNAMIC) Object returnValue,
                            @Advice.Thrown Throwable thrown) {
      Recorder.exit(callId, receiver, returnValue, thrown);
    }
  }

  public static final class Recorder {
    private static final AtomicLong sequence = new AtomicLong();
    private static final ThreadLocal<Integer> depth = ThreadLocal.withInitial(() -> 0);
    private static final ThreadLocal<Deque<Call>> calls = ThreadLocal.withInitial(ArrayDeque::new);
    private static Writer output;
    private static int maxEvents;
    private static final int snapshotMaxDepth = Integer.getInteger("cgtl.flow.lineState.maxDepth", 2);
    private static final int snapshotMaxFields = Integer.getInteger("cgtl.flow.lineState.maxFields", 30);
    private static final int snapshotMaxItems = Integer.getInteger("cgtl.flow.lineState.maxCollectionItems", 20);
    private static final AtomicLong methodEnterCount = new AtomicLong();
    private static final AtomicLong methodExitCount = new AtomicLong();
    private static final AtomicLong methodEnterNanos = new AtomicLong();
    private static final AtomicLong methodExitNanos = new AtomicLong();
    private static final AtomicLong methodSnapshotNanos = new AtomicLong();
    private static final AtomicLong methodCallerNanos = new AtomicLong();
    private static final AtomicLong methodWriteNanos = new AtomicLong();

    public static synchronized void initialize() throws Exception {
      String outputPath = System.getProperty("cgtl.flow.output");
      maxEvents = Integer.getInteger("cgtl.flow.maxEvents", 20000);
      if (outputPath == null) return;
      File file = new File(outputPath); File parent = file.getParentFile(); if (parent != null) parent.mkdirs();
      output = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file, true), StandardCharsets.UTF_8));
      Runtime.getRuntime().addShutdownHook(new Thread(() -> {
        try { output.close(); } catch (Exception ignored) {}
        System.err.println("[CGTL PERF METHOD CAPTURE] enter=" + methodEnterCount.get()
          + " exit=" + methodExitCount.get()
          + " enterTotal=" + nanosToMillis(methodEnterNanos.get())
          + " exitTotal=" + nanosToMillis(methodExitNanos.get())
          + " snapshot=" + nanosToMillis(methodSnapshotNanos.get())
          + " caller=" + nanosToMillis(methodCallerNanos.get())
          + " write=" + nanosToMillis(methodWriteNanos.get()));
      }));
    }

    public static long enter(String className, String methodName, String descriptor, Object receiver, Object[] arguments) {
      long totalStarted = System.nanoTime();
      methodEnterCount.incrementAndGet();
      long callId = sequence.incrementAndGet();
      int currentDepth = depth.get();
      long callerStarted = System.nanoTime();
      StackTraceElement caller = findCaller(className, methodName);
      methodCallerNanos.addAndGet(System.nanoTime() - callerStarted);
      Deque<Call> stack = calls.get();
      Call parentCall = stack.peek();
      String callerReceiver = parentCall == null ? "null" : timedSnapshot(parentCall.receiver, 0, new IdentityHashMap<>());
      String callerArguments = parentCall == null ? "[]" : timedSnapshotArray(parentCall.arguments, new IdentityHashMap<>());
      stack.push(new Call(callId, className, methodName, descriptor, caller, receiver, arguments));
      depth.set(currentDepth + 1);
      write("{\"sequence\":" + callId + ",\"event\":\"enter\",\"callId\":" + callId +
        ",\"className\":" + quote(className) + ",\"methodName\":" + quote(methodName) + ",\"descriptor\":" + quote(descriptor) +
        ",\"depth\":" + currentDepth + ",\"threadId\":" + Thread.currentThread().getId() +
        ",\"threadName\":" + quote(Thread.currentThread().getName()) + callerJson(caller) + ",\"callerReceiver\":" + callerReceiver + ",\"callerArguments\":" + callerArguments + ",\"receiver\":" + timedSnapshot(receiver, 0, new IdentityHashMap<>()) +
        ",\"arguments\":" + timedSnapshotArray(arguments, new IdentityHashMap<>()) + "}");
      methodEnterNanos.addAndGet(System.nanoTime() - totalStarted);
      return callId;
    }

    public static void exit(long callId, Object receiverAfter, Object returnValue, Throwable thrown) {
      long totalStarted = System.nanoTime();
      methodExitCount.incrementAndGet();
      int currentDepth = Math.max(0, depth.get() - 1); depth.set(currentDepth);
      Deque<Call> stack = calls.get();
      Call call = stack.poll();
      Call parentCall = stack.peek();
      long eventId = sequence.incrementAndGet();
      String className = call == null ? "" : call.className; String methodName = call == null ? "" : call.methodName; String descriptor = call == null ? "" : call.descriptor;
      String callerReceiverAfter = parentCall == null ? "null" : timedSnapshot(parentCall.receiver, 0, new IdentityHashMap<>());
      String callerArgumentsAfter = parentCall == null ? "[]" : timedSnapshotArray(parentCall.arguments, new IdentityHashMap<>());
      IdentityHashMap<Object, Boolean> seen = new IdentityHashMap<>();
      write("{\"sequence\":" + eventId + ",\"event\":\"exit\",\"callId\":" + callId +
        ",\"className\":" + quote(className) + ",\"methodName\":" + quote(methodName) + ",\"descriptor\":" + quote(descriptor) +
        ",\"depth\":" + currentDepth + ",\"threadId\":" + Thread.currentThread().getId() + ",\"threadName\":" + quote(Thread.currentThread().getName()) +
        ",\"receiverAfter\":" + timedSnapshot(receiverAfter, 0, new IdentityHashMap<>()) +
        ",\"callerReceiverAfter\":" + callerReceiverAfter +
        ",\"callerArgumentsAfter\":" + callerArgumentsAfter +
        ",\"returnValue\":" + timedSnapshot(returnValue, 0, seen) + ",\"thrown\":" + throwableSnapshot(thrown) + callerJson(call == null ? null : call.caller) + "}");
      methodExitNanos.addAndGet(System.nanoTime() - totalStarted);
    }

    private static StackTraceElement findCaller(String className, String methodName) {
      StackTraceElement[] frames = Thread.currentThread().getStackTrace();
      for (int i = 0; i < frames.length - 1; i++) {
        StackTraceElement frame = frames[i];
        if (className.equals(frame.getClassName()) && methodName.equals(frame.getMethodName())) {
          return frames[i + 1];
        }
      }
      return null;
    }

    private static String callerJson(StackTraceElement caller) {
      if (caller == null) return "";
      return ",\"callerClassName\":" + quote(caller.getClassName()) +
        ",\"callerMethodName\":" + quote(caller.getMethodName()) +
        ",\"callerSourceFile\":" + quote(caller.getFileName()) +
        ",\"callerLine\":" + caller.getLineNumber();
    }

    private static synchronized void write(String json) {
      long started = System.nanoTime();
      try { if (output != null && sequence.get() <= maxEvents) { output.write(json); output.write("\n"); } } catch (Exception ignored) {}
      finally { methodWriteNanos.addAndGet(System.nanoTime() - started); }
    }

    private static String timedSnapshot(Object value, int level, IdentityHashMap<Object, Boolean> seen) {
      long started = System.nanoTime();
      try { return snapshot(value, level, seen); }
      finally { methodSnapshotNanos.addAndGet(System.nanoTime() - started); }
    }

    private static String timedSnapshotArray(Object[] values, IdentityHashMap<Object, Boolean> seen) {
      long started = System.nanoTime();
      try { return snapshotArray(values, seen); }
      finally { methodSnapshotNanos.addAndGet(System.nanoTime() - started); }
    }

    private static String nanosToMillis(long nanos) {
      return String.format(java.util.Locale.ROOT, "%.3fms", nanos / 1_000_000.0);
    }

    public static String snapshotForLine(Object value) {
      try { return snapshot(value, 0, new IdentityHashMap<>()); }
      catch (Throwable error) { return "{\"type\":\"unavailable\",\"value\":" + quote("<" + error.getClass().getSimpleName() + ">") + "}"; }
    }

    private static String snapshotArray(Object[] values, IdentityHashMap<Object, Boolean> seen) {
      if (values == null) return "[]"; StringBuilder result = new StringBuilder("[");
      for (int i = 0; i < values.length; i++) { if (i > 0) result.append(','); result.append(snapshot(values[i], 0, seen)); }
      return result.append(']').toString();
    }

    private static String snapshot(Object value, int level, IdentityHashMap<Object, Boolean> seen) {
      if (value == null) return "null";
      if (value instanceof String || value instanceof Character || value instanceof Enum<?>) return "{\"type\":" + quote(value.getClass().getName()) + ",\"value\":" + quote(limit(String.valueOf(value), 500)) + "}";
      if (value instanceof Number || value instanceof Boolean) return "{\"type\":" + quote(value.getClass().getName()) + ",\"value\":" + quote(String.valueOf(value)) + "}";
      Class<?> type = value.getClass();
      SnapshotAdapters.Adapted adapted = SnapshotAdapters.adapt(value);
      if (adapted != null) return adaptedSnapshot(type, adapted, level, seen);
      if (type.isArray()) { int total = Array.getLength(value); int length = Math.min(total, snapshotMaxItems); StringBuilder out = new StringBuilder("{\"type\":" + quote(type.getName()) + ",\"items\":["); for (int i=0;i<length;i++){if(i>0)out.append(',');out.append(snapshot(Array.get(value,i),level+1,seen));} return out.append("],\"size\":").append(total).append('}').toString(); }
      if (seen.put(value, Boolean.TRUE) != null) return "{\"type\":" + quote(type.getName()) + ",\"value\":\"<cycle>\"}";
      if (value instanceof Map<?,?> map) { StringBuilder out = new StringBuilder("{\"type\":" + quote(type.getName()) + ",\"entries\":["); int i=0; for (Map.Entry<?,?> entry : map.entrySet()) { if (i++ >= snapshotMaxItems) break; if (i > 1) out.append(','); out.append("{\"key\":").append(snapshot(entry.getKey(), level+1, seen)).append(",\"value\":").append(snapshot(entry.getValue(), level+1, seen)).append('}'); } return out.append("],\"size\":").append(map.size()).append('}').toString(); }
      if (value instanceof Collection<?> collection) { StringBuilder out = new StringBuilder("{\"type\":" + quote(type.getName()) + ",\"items\":["); int i=0; for (Object item : collection) { if (i++ >= snapshotMaxItems) break; if (i > 1) out.append(','); out.append(snapshot(item, level+1, seen)); } return out.append("],\"size\":").append(collection.size()).append('}').toString(); }
      if (level >= snapshotMaxDepth) return "{\"type\":" + quote(type.getName()) + ",\"value\":" + quote(identityText(value)) + "}";
      StringBuilder fields = new StringBuilder(); int count = 0;
      for (Class<?> current = type; current != null && current != Object.class && count < snapshotMaxFields; current = current.getSuperclass()) {
        for (Field field : current.getDeclaredFields()) {
          if (Modifier.isStatic(field.getModifiers()) || field.isSynthetic() || count >= snapshotMaxFields) continue;
          if (count++ > 0) fields.append(',');
          fields.append(quote(field.getName())).append(':');
          try { field.setAccessible(true); fields.append(snapshot(field.get(value), level + 1, seen)); }
          catch (Throwable error) { fields.append("{\"type\":\"unavailable\",\"value\":" + quote("<" + error.getClass().getSimpleName() + ">") + "}"); }
        }
      }
      return "{\"type\":" + quote(type.getName()) + ",\"value\":" + quote(identityText(value)) + ",\"fields\":{" + fields + "}}";
    }

    private static String adaptedSnapshot(Class<?> type, SnapshotAdapters.Adapted adapted, int level, IdentityHashMap<Object, Boolean> seen) {
      Object adaptedValue = SnapshotAdapters.sanitizedAdapterValue(adapted);
      StringBuilder out = new StringBuilder("{\"type\":").append(quote(type.getName())).append(",\"adapter\":").append(quote(adapted.adapter));
      if (adapted.display != null) out.append(",\"value\":").append(quote(limit(adapted.display, 500)));
      if (adaptedValue instanceof Map<?,?> map) out.append(",\"fields\":").append(structuredJson(map, level + 1, seen));
      else if (adaptedValue instanceof Collection<?> || (adaptedValue != null && adaptedValue.getClass().isArray())) out.append(",\"items\":").append(structuredJson(adaptedValue, level + 1, seen));
      else if (adapted.display == null) out.append(",\"value\":").append(structuredJson(adaptedValue, level + 1, seen));
      return out.append('}').toString();
    }

    private static String structuredJson(Object value, int level, IdentityHashMap<Object, Boolean> seen) {
      if (value == null) return "null";
      if (SnapshotAdapters.isSimple(value)) return "{\"type\":" + quote(value.getClass().getName()) + ",\"value\":" + quote(limit(String.valueOf(value), 500)) + "}";
      if (value instanceof Map<?,?> map) { StringBuilder out=new StringBuilder("{"); int i=0; for(Map.Entry<?,?> e:map.entrySet()){if(i++>=snapshotMaxFields)break;if(i>1)out.append(',');out.append(quote(String.valueOf(e.getKey()))).append(':').append(structuredJson(e.getValue(),level+1,seen));} return out.append('}').toString(); }
      if (value instanceof Collection<?> collection) { StringBuilder out=new StringBuilder("["); int i=0; for(Object item:collection){if(i++>=snapshotMaxItems)break;if(i>1)out.append(',');out.append(structuredJson(item,level+1,seen));} return out.append(']').toString(); }
      if (value.getClass().isArray()) { StringBuilder out=new StringBuilder("["); int n=Math.min(Array.getLength(value),snapshotMaxItems); for(int i=0;i<n;i++){if(i>0)out.append(',');out.append(structuredJson(Array.get(value,i),level+1,seen));} return out.append(']').toString(); }
      return snapshot(value, level, seen);
    }

    private static String throwableSnapshot(Throwable thrown) {
      if (thrown == null) return "null";
      return "{\"type\":" + quote(thrown.getClass().getName()) + ",\"message\":" + quote(limit(thrown.getMessage(), 1000)) + "}";
    }
    private static String identityText(Object value) {
      if (value == null) return "null";
      return value.getClass().getName() + "@" + Integer.toHexString(System.identityHashCode(value));
    }
    private static String limit(String value, int max) { if (value == null) return ""; return value.length() <= max ? value : value.substring(0, max) + "…"; }
    private static String quote(String value) { if (value == null) return "null"; return "\"" + value.replace("\\", "\\\\").replace("\"", "\\\"").replace("\r", "\\r").replace("\n", "\\n") + "\""; }
    private static final class Call { final long id; final String className, methodName, descriptor; final StackTraceElement caller; final Object receiver; final Object[] arguments; Call(long id,String c,String m,String d,StackTraceElement caller,Object receiver,Object[] arguments){this.id=id;this.className=c;this.methodName=m;this.descriptor=d;this.caller=caller;this.receiver=receiver;this.arguments=arguments == null ? new Object[0] : arguments.clone();} }
  }
}
